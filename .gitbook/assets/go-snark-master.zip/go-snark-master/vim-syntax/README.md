# circuit vim syntax

## Installation in vim/nvim using plug
Using [Plug](https://github.com/junegunn/vim-plug), add this lines into the `.vimrc`/`init.vim`:
```
Plug 'arnaucube/go-snark'
Plug 'arnaucube/go-snark', {'rtp': 'vim-syntax'}
```

![screenshot-vim](https://raw.githubusercontent.com/arnaucube/go-snark/master/vim-syntax/screenshot.png "screenshot-vim")

#!/bin/sh

cd cli && go build
mv ./cli ../go-snark-cli
